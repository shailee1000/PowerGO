package com.example.myapplication;

import android.content.Context;
import android.widget.Button;

public class CustomDialog {
    private Button btnyes,btnno;
    private Context context;

}
