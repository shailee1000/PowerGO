package com.example.myapplication;

public class Shape {
    protected int x,y, color;

    public Shape(int x, int y, int color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }
}