package com.example.myapplication;

public class Abilities  {
    private String abilityName;           // שם הכוח המיוחד
    private String abilityPower;         // אפקט הכוח המיוחד


}
